//
//  JournalView.swift
//  Pulse
//
//  Created by Theint Nay Chi Naing Win on 02/02/2026.
//

import SwiftUI

struct JournalView: View {
    @State private var text: String = ""
    @State private var showSaved = false

    private let limit = 500

    var body: some View {
        VStack(spacing: 12) {
            Text(Date.now.formatted(date: .long, time: .shortened))
                .font(.footnote)
                .foregroundColor(.gray)
                .frame(maxWidth: .infinity, alignment: .leading)

            // Text area
            TextEditor(text: $text)
                .frame(height: 250)
                .padding(8)
                .background(Color(.systemGray6))
                .cornerRadius(12)
                .onChange(of: text) { _, newValue in
                    if newValue.count > limit {
                        text = String(newValue.prefix(limit))
                    }
                }

            // Counter
            Text("\(text.count) / \(limit)")
                .font(.footnote)
                .foregroundColor(.gray)
                .frame(maxWidth: .infinity, alignment: .leading)

            Spacer()
        }
        .padding()
        .navigationTitle("Quick Journal")
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .topBarTrailing) {
                Button("Save") {
                    showSaved = true
                }
                .disabled(text.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
            }
        }
        .alert("Saved!", isPresented: $showSaved) {
            Button("OK", role: .cancel) { }
        } message: {
            Text("Your journal entry was saved.")
        }
    }
}
