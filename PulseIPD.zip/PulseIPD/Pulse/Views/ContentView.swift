//
//  ContentView.swift
//  Pulse
//
//  Created by Theint Nay Chi Naing Win on 02/02/2026.
//

import SwiftUI

struct ContentView: View {
    @State private var lastMood: UserMood? = nil

    var body: some View {
        TabView {
            NavigationStack {
                HomeView(lastMood: $lastMood)
            }
            .tabItem { Label("Home", systemImage: "house") }

            NavigationStack {
                InsightsView(lastMood: $lastMood)
            }
            .tabItem { Label("Insights", systemImage: "chart.bar") }

            NavigationStack {
                JournalView()
            }
            .tabItem { Label("Journal", systemImage: "square.and.pencil") }

            NavigationStack {
                ProfileView()
            }
            .tabItem { Label("Profile", systemImage: "person") }
        }
    }
}
#Preview {
    ContentView()
}
