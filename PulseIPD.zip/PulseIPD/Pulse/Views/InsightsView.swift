//
//  InsightsView.swift
//  Pulse
//
//  Created by Theint Nay Chi Naing Win on 04/02/2026.
//
import SwiftUI

struct InsightsView: View {
    @Binding var lastMood: UserMood?

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 16) {

                // Header
                VStack(alignment: .leading, spacing: 6) {
                    Text("Insights")
                        .font(.title2).bold()
                        .foregroundColor(.white)

                    Text("Your wellness journey")
                        .font(.subheadline)
                        .foregroundColor(.white.opacity(0.9))
                }
                .frame(maxWidth: .infinity, alignment: .leading)
                .padding()
                .background(Color.blue)
                .clipShape(RoundedRectangle(cornerRadius: 16))

                // Cards
                HStack(spacing: 12) {
                    insightCard(
                        title: "Avg Mood",
                        value: lastMood?.rawValue ?? "N/A"
                    )

                    insightCard(
                        title: "Day Streak",
                        value: "0"
                    )
                }

                Spacer(minLength: 20)
            }
            .padding()
        }
        .background(Color(.systemGroupedBackground))
        .navigationTitle("Insights")
        .navigationBarTitleDisplayMode(.inline)
    }

    private func insightCard(title: String, value: String) -> some View {
        VStack(alignment: .leading, spacing: 8) {
            Text(value)
                .font(.title3).bold()
            Text(title)
                .font(.footnote)
                .foregroundColor(.secondary)
        }
        .padding()
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(Color.white)
        .clipShape(RoundedRectangle(cornerRadius: 16))
        .shadow(radius: 1, y: 1)
    }
}
