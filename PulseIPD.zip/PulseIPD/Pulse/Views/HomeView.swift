//
//  Homeview.swift
//  Pulse
//
//  Created by Theint Nay Chi Naing Win on 02/02/2026.
//

import SwiftUI

struct HomeView: View {
    @Binding var lastMood: UserMood?

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 16) {

                // Header 
                VStack(alignment: .leading, spacing: 6) {
                    Text("Good day,")
                        .foregroundColor(.white)
                        .font(.subheadline)

                    Text("Skye")
                        .foregroundColor(.white)
                        .font(.title2).bold()

                    Text(Date.now.formatted(date: .abbreviated, time: .omitted))
                        .foregroundColor(.white.opacity(0.9))
                        .font(.footnote)
                }
                .frame(maxWidth: .infinity, alignment: .leading)
                .padding()
                .background(Color.blue)
                .clipShape(RoundedRectangle(cornerRadius: 18))

                // Mood
                NavigationLink {
                    LogMoodView(lastMood: $lastMood)
                } label: {
                    VStack(alignment: .leading, spacing: 6) {
                        Text("How are you feeling?")
                            .font(.headline)
                            .foregroundColor(.primary)

                        HStack {
                            if let mood = lastMood {
                                Text("\(mood.emoji) \(mood.rawValue)")
                                    .foregroundColor(.secondary)
                            } else {
                                Text("Tap to log your mood")
                                    .foregroundColor(.secondary)
                            }

                            Spacer()
                            Image(systemName: "chevron.right")
                                .foregroundColor(.secondary)
                        }
                    }
                    .padding()
                    .background(Color.white)
                    .clipShape(RoundedRectangle(cornerRadius: 16))
                    .shadow(radius: 1, y: 1)
                }
                .buttonStyle(.plain)

                Text("Recommended for you")
                    .font(.headline)
                    .padding(.top, 6)

                // Breathing
                NavigationLink {
                    BreathingView()
                } label: {
                    RecommendationCard(
                        title: "Breathing Exercise",
                        subtitle: "5 min · Find your centre",
                        icon: "lungs.fill"
                    )
                }
                .buttonStyle(.plain)

                // Meditation (placeholder)
                Button {
                } label: {
                    RecommendationCard(
                        title: "Meditation",
                        subtitle: "10 min · Clear your mind",
                        icon: "figure.mind.and.body"
                    )
                }
                .buttonStyle(.plain)

                Spacer(minLength: 20)
            }
            .padding()
        }
        .background(Color(.systemGroupedBackground))
        .navigationTitle("Home")
        .navigationBarTitleDisplayMode(.inline)
    }
}


struct RecommendationCard: View {
    let title: String
    let subtitle: String
    let icon: String

    var body: some View {
        HStack(spacing: 12) {
            Image(systemName: icon)
                .frame(width: 36, height: 36)
                .background(Color(.systemGray6))
                .clipShape(Circle())
                .foregroundColor(.blue)

            VStack(alignment: .leading, spacing: 4) {
                Text(title)
                    .foregroundColor(.primary)
                    .font(.headline)

                Text(subtitle)
                    .foregroundColor(.secondary)
                    .font(.subheadline)
            }

            Spacer()

            Image(systemName: "chevron.right")
                .foregroundColor(.secondary)
        }
        .padding()
        .background(Color.white)
        .clipShape(RoundedRectangle(cornerRadius: 16))
        .shadow(radius: 1, y: 1)
    }
}
