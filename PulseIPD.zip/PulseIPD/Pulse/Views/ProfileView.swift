//
//  ProfileView.swift
//  Pulse
//
//  Created by Theint Nay Chi Naing Win on 04/02/2026.
//

import SwiftUI

struct ProfileView: View {
    @AppStorage("pushNotificationsEnabled") private var pushNotificationsEnabled = true
    @AppStorage("dailyMoodReminderEnabled") private var dailyMoodReminderEnabled = true
    @AppStorage("themePreference") private var themePreference: String = "auto"

    var body: some View {
        List {
            VStack(spacing: 6) {
                Image(systemName: "person.circle.fill")
                    .font(.system(size: 52))
                    .foregroundColor(.blue)

                Text("skye")
                    .font(.title3).bold()
            }
            .frame(maxWidth: .infinity)
            .padding(.vertical, 12)
            .listRowBackground(Color.clear)

            Section("Notifications") {
                Toggle("Push Notifications", isOn: $pushNotificationsEnabled)
                Toggle("Daily Mood Reminder", isOn: $dailyMoodReminderEnabled)
            }

            Section("Preferences") {
                Picker("Theme", selection: $themePreference) {
                    Text("Auto (System)").tag("auto")
                    Text("Light").tag("light")
                    Text("Dark").tag("dark")
                }
            }
        }
        .navigationTitle("Profile")
        .navigationBarTitleDisplayMode(.inline)
        .scrollContentBackground(.hidden)
        .background(Color(.systemGroupedBackground))
        .preferredColorScheme(colorSchemeFromPreference(themePreference))
    }

    private func colorSchemeFromPreference(_ pref: String) -> ColorScheme? {
        switch pref {
        case "light": return .light
        case "dark": return .dark
        default: return nil // autsystem
        }
    }
}
