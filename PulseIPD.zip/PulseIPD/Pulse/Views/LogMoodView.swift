//
//  LogMoodView.swift
//  Pulse
//
//  Created by Theint Nay Chi Naing Win on 02/02/2026.
//

import SwiftUI

struct LogMoodView: View {
    @Binding var lastMood: UserMood?

    @State private var moodValue: Double = 2   // 0...4
    @State private var showSaved = false

    private let moods: [UserMood] = [.sad, .anxious, .okay, .calm, .good]

    private var currentMood: UserMood {
        moods[Int(moodValue)]
    }

    var body: some View {
        VStack(spacing: 16) {
            Text("Log Your Mood")
                .font(.title2)

            Text(currentMood.emoji)
                .font(.system(size: 60))

            Text(currentMood.rawValue)
                .font(.title3)

            Slider(value: $moodValue, in: 0...4, step: 1)
                .padding(.horizontal)

            Button("Save Mood") {
                lastMood = currentMood
                showSaved = true
            }
            .buttonStyle(.borderedProminent)

            Spacer()
        }
        .padding()
        .navigationTitle("Log Mood")
        .navigationBarTitleDisplayMode(.inline)
        .alert("Saved!", isPresented: $showSaved) {
            Button("OK", role: .cancel) {}
        }
    }
}
