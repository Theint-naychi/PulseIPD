//
//  BreathingView.swift
//  Pulse
//
//  Created by Theint Nay Chi Naing Win on 04/02/2026.
//
import SwiftUI

struct BreathingView: View {
    var body: some View {
        VStack(spacing: 16) {
            Text("Breathing Exercise")
                .font(.title2)

            Text("Box Breathing")
                .foregroundColor(.gray)

            Circle()
                .stroke(lineWidth: 4)
                .frame(width: 200, height: 200)

            Text("Ready")

            Spacer()
        }
        .padding()
        .navigationTitle("Breathing")
        .navigationBarTitleDisplayMode(.inline)
    }
}
